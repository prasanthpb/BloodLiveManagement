﻿using BloodBankWPFApplication;

namespace services
{
    public class DonorService
    {
        //method to add new donor info
        public int AddDonor(DonorDetail donor)
        {
            using (var dbContext = new BloodBankDBEntities())
            {
                dbContext.DonorDetails.Add(donor);
                dbContext.SaveChanges();
            }
            return 0;
        }
        //method to add new donor address info
        //return id stored info
        public int AddDonorAddress(Address address)
        {
            using (var dbContext = new BloodBankDBEntities())
            {
                dbContext.Addresses.Add(address);
                dbContext.SaveChanges();
            }
            return address.addressId;
        }
    }
}