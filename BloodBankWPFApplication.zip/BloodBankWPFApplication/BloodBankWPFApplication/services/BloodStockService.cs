﻿using System;
using BloodBankWPFApplication;

namespace services
{
    internal class BloodStockService
    {
        //method to add new blood stock info
        internal int AddBloodStock(BloodStock bloodstock)
        {
            using (var dbContext = new BloodBankDBEntities())
            {
                dbContext.BloodStocks.Add(bloodstock);
                dbContext.SaveChanges();
            }
            return 0;
        }
    }
}