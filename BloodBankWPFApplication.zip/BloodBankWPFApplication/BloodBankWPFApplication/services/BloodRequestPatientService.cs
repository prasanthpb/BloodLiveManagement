﻿using BloodBankWPFApplication;

namespace services
{
    internal class BloodRequestPatientService
    {
        BloodBankDBEntities bloodBankDBEntities = new BloodBankDBEntities();

        //method to add new patient details
        public int AddPatient(BloodRequestPatientDetail patient)
        {
            using (var dbContext = new BloodBankDBEntities())
            {
                dbContext.BloodRequestPatientDetails.Add(patient);
                dbContext.SaveChanges();
            }
            return 0;
        }
        //method to address hospital address info
        //return id of stored info
        public int AddHospitalAddress(Address address)
        {
            using (var dbContext = new BloodBankDBEntities())
            {
                dbContext.Addresses.Add(address);
                dbContext.SaveChanges();
            }
            return address.addressId;
        }
    }
}