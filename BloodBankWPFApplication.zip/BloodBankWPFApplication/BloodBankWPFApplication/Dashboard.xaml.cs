﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Controls.DataVisualization;
using System.Windows.Controls.Primitives;
using System.Windows.Controls.DataVisualization.Charting;

namespace BloodBankWPFApplication
{
    /// <summary>
    /// Interaction logic for Dashboard.xaml
    /// </summary>
    public partial class Dashboard : Window
    {
        public Dashboard()
        {
            InitializeComponent();
            WindowStartupLocation = WindowStartupLocation.CenterScreen;

            var query = from d in bloodBankDBEntities.DonorDetails
                        join a in bloodBankDBEntities.Addresses
                        on d.addressId equals a.addressId
                        //where
                        select new { d.firstName, d.bloodGroup };
            //display the returned data list into datagrid
          var collections = query.ToList();
            
            List<BloodGroup> bloodGroupABPositive = new List<BloodGroup>();
            List<BloodGroup> bloodGroupABNegative = new List<BloodGroup>();
            List<BloodGroup> bloodGroupOPositive = new List<BloodGroup>();
            List<BloodGroup> bloodGroupONegative = new List<BloodGroup>();
            List<BloodGroup> bloodGroupBPositive = new List<BloodGroup>();
            List<BloodGroup> bloodGroupBNegative = new List<BloodGroup>();
            List<BloodGroup> bloodGroupAPositive = new List<BloodGroup>();
            List<BloodGroup> bloodGroupANegative = new List<BloodGroup>();

            foreach (var i in collections)
            {
                if (i.bloodGroup.Equals("AB+"))
                {                    
                    bloodGroupABPositive.Add(new BloodGroup { Name = i.bloodGroup, Share = 0 });
                }
                else if (i.bloodGroup.Equals("AB-"))
                {
                    bloodGroupABNegative.Add(new BloodGroup { Name = i.bloodGroup, Share = 0 });
                }
                else if (i.bloodGroup.Equals("O+"))
                {
                    bloodGroupOPositive.Add(new BloodGroup { Name = i.bloodGroup, Share = 0 });
                }
                else if (i.bloodGroup.Equals("O-"))
                {
                    bloodGroupONegative.Add(new BloodGroup { Name = i.bloodGroup, Share = 0 });
                }
                else if (i.bloodGroup.Equals("B+"))
                {
                    bloodGroupBPositive.Add(new BloodGroup { Name = i.bloodGroup, Share = 0 });
                }
                else if (i.bloodGroup.Equals("B-"))
                {
                    bloodGroupBNegative.Add(new BloodGroup { Name = i.bloodGroup, Share = 0 });
                }
                else if (i.bloodGroup.Equals("A+"))
                {
                    bloodGroupAPositive.Add(new BloodGroup { Name = i.bloodGroup, Share = 0 });
                }
                else
                {
                    if (i.bloodGroup.Equals("A-"))
                    {
                        bloodGroupANegative.Add(new BloodGroup { Name = i.bloodGroup, Share = 0 });
                    }
                }
            }
            List<BloodGroup> mainbloodGroupsCollections = new List<BloodGroup>() 
            {
                new BloodGroup { Name = "AB+", Share = bloodGroupABPositive.Count() },
                new BloodGroup { Name = "AB-", Share = bloodGroupABNegative.Count() },
                new BloodGroup { Name = "O+", Share = bloodGroupOPositive.Count() },
                new BloodGroup { Name = "O-", Share = bloodGroupONegative.Count() },
                new BloodGroup { Name = "B+", Share = bloodGroupBPositive.Count() },
                new BloodGroup { Name = "B-", Share = bloodGroupBNegative.Count() },
                new BloodGroup { Name = "A+", Share = bloodGroupAPositive.Count() },
                new BloodGroup { Name = "A-", Share = bloodGroupANegative.Count() }
            };
            ////BloodCollections bloodGroups = new BloodCollections(mainbloodGroupsCollections);
            ((BarSeries)mcChartSrc).ItemsSource = mainbloodGroupsCollections;
        }

        BloodBankDBEntities bloodBankDBEntities = new BloodBankDBEntities();

        private void LoadBarChartData()
        {
            //((BarSeries)mcChart.Series[0]).ItemsSource = bloodGroups;
            //new KeyValuePair<string, int>[]{
            //new KeyValuePair<string, int>("Project Manager", 12),
            //new KeyValuePair<string, int>("CEO", 25),
            //new KeyValuePair<string, int>("Software Engg.", 5),
            //new KeyValuePair<string, int>("Team Leader", 6),
            //new KeyValuePair<string, int>("Project Leader", 10),
            //new KeyValuePair<string, int>("Developer", 4) };
        }

        //all the events to hide current form and display respective form
        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Home home = new Home();
            home.Show();
        }

        private void btnSearchBlood_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            SearchBloodForm sbf = new SearchBloodForm();
            sbf.Show();
        }

        private void btnBloodStock_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            BloodStock bs = new BloodStock();
            bs.Show();
        }

        private void btnRequestBlood_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            BloodRequest br = new BloodRequest();
            br.Show();
        }
    }
}
