﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BloodBankWPFApplication
{
    internal class BloodCollections : System.Collections.ObjectModel.Collection<BloodGroup>
    {
        private List<BloodGroup> bloodCollection;

        public List<BloodGroup> BloodCollection
        {
            get { return bloodCollection; }
            set { bloodCollection = value; }
        }


        public BloodCollections(List<BloodGroup> bloodGroups)
        {
            BloodCollection = bloodGroups;
        }

        public BloodCollections()
        {
            ////return BloodCollection;
            ////Add(new BloodGroup { Name = "AB+", Share = 10 });
            ////Add(new BloodGroup { Name = "AB-", Share = 36 });
            ////Add(new BloodGroup { Name = "O+", Share = 24 });
            ////Add(new BloodGroup { Name = "O-", Share = 4 });
            ////Add(new BloodGroup { Name = "B+", Share = 12 });
            ////Add(new BloodGroup { Name = "B-", Share = 10 });
            ////Add(new BloodGroup { Name = "A+", Share = 4 });
            ////Add(new BloodGroup { Name = "A-", Share = 4 });
        }
    }
}